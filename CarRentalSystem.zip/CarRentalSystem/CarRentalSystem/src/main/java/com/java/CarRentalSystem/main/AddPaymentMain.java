package com.java.CarRentalSystem.main;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Payment;


public class AddPaymentMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter payment ID: ");
		int paymentID = sc.nextInt();
		
		System.out.println("Enter lease ID: ");
		int leaseID = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter payment Date: ");
		String paymentDate= sc.nextLine();
		
		System.out.println("Enter amount: ");
		double amount = sc.nextDouble();
		
		
		CarRentalSystem dao = new CarRentalSystemImpl();
		Payment payment=new Payment(paymentID,leaseID,Date.valueOf(paymentDate),amount);
		try {
			System.out.println(dao.addPayment(payment));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
