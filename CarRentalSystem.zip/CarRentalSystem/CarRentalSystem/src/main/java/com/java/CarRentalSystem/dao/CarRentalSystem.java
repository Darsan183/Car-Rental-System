package com.java.CarRentalSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.CarRentalSystem.model.Customer;
import com.java.CarRentalSystem.model.Lease;
import com.java.CarRentalSystem.model.Payment;
import com.java.CarRentalSystem.model.Vehicle;

public interface CarRentalSystem {

	 List<Vehicle> getAllVehicles() throws ClassNotFoundException, SQLException;
	 List<Vehicle> getVehiclesByMake(String make) throws ClassNotFoundException,SQLException;
	 List<Vehicle> getVehiclesByModel(String model) throws ClassNotFoundException, SQLException;
	 List<Vehicle> getVehiclesByYear(int year) throws ClassNotFoundException, SQLException;
	 List<Vehicle> getVehiclesByPassengerCapacity(int capacity) throws ClassNotFoundException, SQLException;
	 String addVehicle(Vehicle vehicle) throws ClassNotFoundException, SQLException;
	 
	 String addCustomer(Customer customer) throws ClassNotFoundException, SQLException;
	 List<Customer> getAllCustomers() throws ClassNotFoundException, SQLException;
	 List<Customer> getCustomerById(int customerId) throws ClassNotFoundException, SQLException;
	 
	 List<Lease> getAllLeases() throws ClassNotFoundException, SQLException;
	 List<Lease> getLeaseById(int leaseId) throws ClassNotFoundException, SQLException;
	 List<Lease> getLeasesByCustomerId(int customerId) throws ClassNotFoundException, SQLException;
	 List<Lease> getLeasesByDateRange(String startDate, String endDate) throws ClassNotFoundException, SQLException;
	 List<Lease> getLeasesByType(String type) throws ClassNotFoundException, SQLException;
	 String addLease(Lease lease) throws ClassNotFoundException, SQLException;
	 
	 List<Payment> getPaymentsByLeaseId(int leaseId) throws ClassNotFoundException, SQLException;
	 String addPayment(Payment payment) throws ClassNotFoundException, SQLException;
}
