package com.java.CarRentalSystem.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Lease;

public class ShowLeaseByCustomerID {

	 public static void main(String[] args) {
	        try {
	            CarRentalSystem dao = new CarRentalSystemImpl();
	            Scanner scanner = new Scanner(System.in);
	            System.out.print("Enter customerID: ");
	            int customerID = scanner.nextInt();

	            List<Lease> leases = dao.getLeasesByCustomerId(customerID);
	            if (leases.isEmpty()) {
	                System.out.println("No record found.");
	            } else {
	                System.out.println("Details of the lease with customerID (" + customerID + "):");
	                for (Lease lease : leases) {
	                    System.out.println(lease);
	                }
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
