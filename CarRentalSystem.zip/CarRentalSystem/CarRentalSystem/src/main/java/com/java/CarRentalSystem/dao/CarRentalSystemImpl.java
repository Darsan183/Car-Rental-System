package com.java.CarRentalSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import com.java.CarRentalSystem.model.Customer;
import com.java.CarRentalSystem.model.Lease;
import com.java.CarRentalSystem.model.Payment;
import com.java.CarRentalSystem.model.Status;
import com.java.CarRentalSystem.model.Type;
import com.java.CarRentalSystem.model.Vehicle;
import com.java.CarRentalSystem.util.DBConnUtil;
import com.java.CarRentalSystem.util.DBPropertyUtil;



public class CarRentalSystemImpl implements CarRentalSystem {

	Connection connection;
	PreparedStatement pst;
	
	@Override
	public List<Vehicle> getAllVehicles() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM vehicle";
        PreparedStatement pst = connection.prepareStatement(cmd);
        ResultSet rs = pst.executeQuery();
        
        List<Vehicle> vehicleList = new ArrayList<>();
        while(rs.next()) {
            Vehicle vehicle = new Vehicle();
            vehicle.setVehicleID(rs.getInt("vehicleID"));
            vehicle.setMake(rs.getString("make"));
            vehicle.setModel(rs.getString("model"));
            vehicle.setYear(rs.getInt("year"));
            vehicle.setDailyRate(rs.getDouble("dailyRate"));
            vehicle.setStatus(Status.valueOf(rs.getString("status")));
            vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
            vehicle.setEngineCapacity(rs.getInt("engineCapacity"));
            
            vehicleList.add(vehicle);
        }
        
        return vehicleList;
    }
      

	@Override
	public List<Vehicle> getVehiclesByMake(String make) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM vehicle WHERE make = ?";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setString(1, make);
        ResultSet rs = pst.executeQuery();

        List<Vehicle> vehicleList = new ArrayList<>();
        while (rs.next()) {
            Vehicle vehicle = new Vehicle();
            vehicle.setVehicleID(rs.getInt("vehicleID"));
            vehicle.setMake(rs.getString("make"));
            vehicle.setModel(rs.getString("model"));
            vehicle.setYear(rs.getInt("year"));
            vehicle.setDailyRate(rs.getDouble("dailyRate"));
            vehicle.setStatus(Status.valueOf(rs.getString("status")));
            vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
            vehicle.setEngineCapacity(rs.getInt("engineCapacity"));

            vehicleList.add(vehicle);
        }

        return vehicleList;
    }
	

	@Override
	public List<Vehicle> getVehiclesByModel(String model) throws ClassNotFoundException, SQLException {
		 String connStr = DBPropertyUtil.getConnectionString("db");
	        Connection connection = DBConnUtil.GetConnection(connStr);
	        String cmd = "SELECT * FROM vehicle WHERE model = ?";
	        PreparedStatement pst = connection.prepareStatement(cmd);
	        pst.setString(1, model);
	        ResultSet rs = pst.executeQuery();

	        List<Vehicle> vehicleList = new ArrayList<>();
	        while (rs.next()) {
	            Vehicle vehicle = new Vehicle();
	            vehicle.setVehicleID(rs.getInt("vehicleID"));
	            vehicle.setMake(rs.getString("make"));
	            vehicle.setModel(rs.getString("model"));
	            vehicle.setYear(rs.getInt("year"));
	            vehicle.setDailyRate(rs.getDouble("dailyRate"));
	            vehicle.setStatus(Status.valueOf(rs.getString("status")));
	            vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
	            vehicle.setEngineCapacity(rs.getInt("engineCapacity"));

	            vehicleList.add(vehicle);
	        }

	        return vehicleList;
	}

	@Override
	public List<Vehicle> getVehiclesByYear(int year) throws ClassNotFoundException, SQLException {
		    String connStr = DBPropertyUtil.getConnectionString("db");
	        Connection connection = DBConnUtil.GetConnection(connStr);
	        String cmd = "SELECT * FROM vehicle WHERE year = ?";
	        PreparedStatement pst = connection.prepareStatement(cmd);
	        pst.setInt(1, year);
	        ResultSet rs = pst.executeQuery();

	        List<Vehicle> vehicleList = new ArrayList<>();
	        while (rs.next()) {
	            Vehicle vehicle = new Vehicle();
	            vehicle.setVehicleID(rs.getInt("vehicleID"));
	            vehicle.setMake(rs.getString("make"));
	            vehicle.setModel(rs.getString("model"));
	            vehicle.setYear(rs.getInt("year"));
	            vehicle.setDailyRate(rs.getDouble("dailyRate"));
	            vehicle.setStatus(Status.valueOf(rs.getString("status")));
	            vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
	            vehicle.setEngineCapacity(rs.getInt("engineCapacity"));

	            vehicleList.add(vehicle);
	        }

	        return vehicleList;
	}

	@Override
	public List<Vehicle> getVehiclesByPassengerCapacity(int passengerCapacity) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM vehicle WHERE passengerCapacity = ?";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setInt(1, passengerCapacity);
        ResultSet rs = pst.executeQuery();

        List<Vehicle> vehicleList = new ArrayList<>();
        while (rs.next()) {
            Vehicle vehicle = new Vehicle();
            vehicle.setVehicleID(rs.getInt("vehicleID"));
            vehicle.setMake(rs.getString("make"));
            vehicle.setModel(rs.getString("model"));
            vehicle.setYear(rs.getInt("year"));
            vehicle.setDailyRate(rs.getDouble("dailyRate"));
            vehicle.setStatus(Status.valueOf(rs.getString("status")));
            vehicle.setPassengerCapacity(rs.getInt("passengerCapacity"));
            vehicle.setEngineCapacity(rs.getInt("engineCapacity"));

            vehicleList.add(vehicle);
        }

        rs.close();
        pst.close();
        connection.close();

        return vehicleList;

	}

	@Override
	public String addVehicle(Vehicle vehicle) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "INSERT INTO vehicle (make, model, year, dailyRate, status, passengerCapacity, engineCapacity) VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setString(1, vehicle.getMake());
        pst.setString(2, vehicle.getModel());
        pst.setInt(3, vehicle.getYear());
        pst.setDouble(4, vehicle.getDailyRate());
        pst.setString(5, vehicle.getStatus().name()); 
        pst.setInt(6, vehicle.getPassengerCapacity());
        pst.setInt(7, vehicle.getEngineCapacity());
        pst.executeUpdate();
        return "Vehicle Record Inserted";
	}

	@Override
	public String addCustomer(Customer customer) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "INSERT INTO customer (firstName, lastName, email, phoneNumber) VALUES (?, ?, ?, ?)";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setString(1, customer.getFirstName());
        pst.setString(2, customer.getLastName());
        pst.setString(3, customer.getEmail()); 
        pst.setString(4, customer.getPhoneNumber());
        
        pst.executeUpdate();
        return "Customer Record Inserted";
	}

	@Override
	public List<Customer> getAllCustomers()  throws ClassNotFoundException, SQLException  {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM customer";
        PreparedStatement pst = connection.prepareStatement(cmd);
        ResultSet rs = pst.executeQuery();
        
        List<Customer> customerList = new ArrayList<>();
        while(rs.next()) {
        	Customer customer = new Customer();
        	customer.setCustomerID(rs.getInt("customerID"));
        	customer.setFirstName(rs.getString("firstName"));
        	customer.setLastName(rs.getString("lastName"));
        	customer.setEmail(rs.getString("email"));
        	customer.setPhoneNumber(rs.getString("phoneNumber"));
            
        	customerList.add(customer);
        }
        
        return customerList;
	}

	@Override
	public List<Customer> getCustomerById(int customerId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM customer WHERE customerID = ?";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setInt(1, customerId);
        ResultSet rs = pst.executeQuery();

        List<Customer> customerList = new ArrayList<>();
        while (rs.next()) {
        	Customer customer = new Customer();
        	customer.setCustomerID(rs.getInt("customerID"));
        	customer.setFirstName(rs.getString("firstName"));
        	customer.setLastName(rs.getString("lastName"));
        	customer.setEmail(rs.getString("email"));
        	customer.setPhoneNumber(rs.getString("phoneNumber"));
            
        	customerList.add(customer);
        }

        return customerList;
	}

	@Override
	public List<Lease> getAllLeases() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM lease";
        PreparedStatement pst = connection.prepareStatement(cmd);
        ResultSet rs = pst.executeQuery();
        
        List<Lease> leaseList = new ArrayList<>();
        while(rs.next()) {
        	Lease lease = new Lease();
        	lease.setLeaseID(rs.getInt("leaseID"));
        	lease.setVehicleID(rs.getInt("vehicleID"));
        	lease.setCustomerID(rs.getInt("customerID"));
        	lease.setStartDate(rs.getDate("startDate"));
        	lease.setEndDate(rs.getDate("endDate"));
        	lease.setType(Type.valueOf(rs.getString("type")));
        	
        	leaseList.add(lease);
        }
        
        return leaseList;
	}

	@Override
	public List<Lease> getLeaseById(int leaseId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM lease WHERE leaseID = ?";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setInt(1, leaseId);
        ResultSet rs = pst.executeQuery();

        List<Lease> leaseList = new ArrayList<>();
        while (rs.next()) {
        	Lease lease = new Lease();
        	lease.setLeaseID(rs.getInt("leaseID"));
        	lease.setVehicleID(rs.getInt("vehicleID"));
        	lease.setCustomerID(rs.getInt("customerID"));
        	lease.setStartDate(rs.getDate("startDate"));
        	lease.setEndDate(rs.getDate("endDate"));
        	lease.setType(Type.valueOf(rs.getString("type")));
        	
        	leaseList.add(lease);
        }

        return leaseList;
	}

	@Override
	public List<Lease> getLeasesByCustomerId(int customerId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM lease WHERE customerId = ?";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setInt(1, customerId);
        ResultSet rs = pst.executeQuery();

        List<Lease> leaseList = new ArrayList<>();
        while (rs.next()) {
        	Lease lease = new Lease();
        	lease.setLeaseID(rs.getInt("leaseID"));
        	lease.setVehicleID(rs.getInt("vehicleID"));
        	lease.setCustomerID(rs.getInt("customerID"));
        	lease.setStartDate(rs.getDate("startDate"));
        	lease.setEndDate(rs.getDate("endDate"));
        	lease.setType(Type.valueOf(rs.getString("type")));
        	
        	leaseList.add(lease);
        }

        return leaseList;
	}

	@Override
	public List<Lease> getLeasesByDateRange(String startDate, String endDate) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
	    Connection connection = DBConnUtil.GetConnection(connStr);
	    String cmd = "SELECT * FROM lease WHERE  startDate >= ? AND endDate <= ?";
	    PreparedStatement pst = connection.prepareStatement(cmd);
	    pst.setDate(1, java.sql.Date.valueOf(startDate));
	    pst.setDate(2, java.sql.Date.valueOf(endDate));
	    ResultSet rs = pst.executeQuery();

	    List<Lease> leaseList = new ArrayList<>();
	    while (rs.next()) {
	        Lease lease = new Lease();
	        lease.setLeaseID(rs.getInt("leaseID"));
	        lease.setVehicleID(rs.getInt("vehicleID"));
	        lease.setCustomerID(rs.getInt("customerID"));
	        lease.setStartDate(rs.getDate("startDate"));
	        lease.setEndDate(rs.getDate("endDate"));
	        lease.setType(Type.valueOf(rs.getString("type")));

	        leaseList.add(lease);
	    }

	    return leaseList;
	}

	@Override
	public List<Lease> getLeasesByType(String type) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM lease WHERE type = ?";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setString(1, type);
        ResultSet rs = pst.executeQuery();

        List<Lease> leaseList = new ArrayList<>();
        while (rs.next()) {
        	Lease lease = new Lease();
        	lease.setLeaseID(rs.getInt("leaseID"));
        	lease.setVehicleID(rs.getInt("vehicleID"));
        	lease.setCustomerID(rs.getInt("customerID"));
        	lease.setStartDate(rs.getDate("startDate"));
        	lease.setEndDate(rs.getDate("endDate"));
        	lease.setType(Type.valueOf(rs.getString("type")));
        	
        	leaseList.add(lease);
        }

        return leaseList;
	}

	@Override
	public String addLease(Lease lease) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "INSERT INTO lease (leaseID,vehicleID, customerID, startDate, endDate, type) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setInt(1, lease.getLeaseID());
        pst.setInt(2, lease.getVehicleID());
        pst.setInt(3, lease.getCustomerID());
        pst.setDate(4, lease.getStartDate()); 
        pst.setDate(5, lease.getEndDate());
        pst.setString(6,lease.getType().toString());
        
        pst.executeUpdate();
        return "Customer Record Inserted";
	}

	@Override
	public List<Payment> getPaymentsByLeaseId(int leaseId) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "SELECT * FROM payment WHERE leaseId = ?";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setInt(1, leaseId);
        ResultSet rs = pst.executeQuery();

        List<Payment> paymentList = new ArrayList<>();
        while (rs.next()) {
        	Payment payment = new Payment();
        	payment.setPaymentID(rs.getInt("paymentID"));
        	payment.setLeaseID(rs.getInt("leaseID"));
        	payment.setPaymentDate(rs.getDate("paymentDate"));
        	payment.setAmount(rs.getDouble("amount"));
        	
        	paymentList.add(payment);
        }

        return paymentList;
	}

	@Override
	public String addPayment(Payment payment) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.getConnectionString("db");
        Connection connection = DBConnUtil.GetConnection(connStr);
        String cmd = "INSERT INTO payment (paymentID,leaseID, paymentDate, amount ) VALUES (?, ?, ?, ?)";
        PreparedStatement pst = connection.prepareStatement(cmd);
        pst.setInt(1,payment.getPaymentID());
        pst.setInt(2, payment.getLeaseID());
        pst.setDate(3, payment.getPaymentDate());
        pst.setDouble(4, payment.getAmount());
        
        pst.executeUpdate();
        return "Payment Record Inserted";
	}

}
