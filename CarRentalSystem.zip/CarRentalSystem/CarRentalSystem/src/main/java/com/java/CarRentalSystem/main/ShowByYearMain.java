package com.java.CarRentalSystem.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Vehicle;

public class ShowByYearMain {

	 public static void main(String[] args) {
	        try {
	            CarRentalSystem dao = new CarRentalSystemImpl();
	            Scanner scanner = new Scanner(System.in);
	            System.out.print("Enter Year: ");
	            int year = scanner.nextInt();

	            List<Vehicle> vehicles = dao.getVehiclesByYear(year);
	            if (vehicles.isEmpty()) {
	                System.out.println("No record found.");
	            } else {
	                System.out.println("Vehicles by Year (" + year + "):");
	                for (Vehicle vehicle : vehicles) {
	                    System.out.println(vehicle);
	                }
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
