package com.java.CarRentalSystem.main;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Lease;

public class ShowLeaseByDate {

	 public static void main(String[] args) {
	        try {
	            CarRentalSystem dao = new CarRentalSystemImpl();
	            Scanner scanner = new Scanner(System.in);
	            System.out.print("Enter start date: ");
	            String startDate = scanner.nextLine().trim();
	            System.out.print("Enter start date: ");
	            String endDate = scanner.nextLine().trim();
	            List<Lease> leases = dao.getLeasesByDateRange(startDate,endDate);
	            if (leases.isEmpty()) {
	                System.out.println("No record found.");
	            } else {
	                System.out.println("Details of the lease within " + startDate + " and "+ endDate);
	                for (Lease lease : leases) {
	                    System.out.println(lease);
	                }
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
