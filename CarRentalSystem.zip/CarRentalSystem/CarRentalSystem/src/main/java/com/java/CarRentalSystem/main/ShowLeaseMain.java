package com.java.CarRentalSystem.main;

import java.sql.SQLException;
import java.util.List;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Lease;

public class ShowLeaseMain {

	public static void main(String[] args) {
		
	CarRentalSystem dao = new CarRentalSystemImpl();
	
	try {
		List<Lease> leaseList = dao.getAllLeases();
		for (Lease lease : leaseList) {
			System.out.println(lease);
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

