package com.java.CarRentalSystem.model;

public enum Status {
	available,notAvailable
}
