package com.java.CarRentalSystem.main;

import java.sql.SQLException;
import java.util.List;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Vehicle;

public class ShowVehicleMain {

public static void main(String[] args) {
		
		CarRentalSystem dao = new CarRentalSystemImpl();
		try {
			List<Vehicle> vehicleList = dao.getAllVehicles();
			for (Vehicle vehicle : vehicleList) {
				System.out.println(vehicle);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
