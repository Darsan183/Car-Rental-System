package com.java.CarRentalSystem.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Customer;



public class AddCustomerMain {

	public static void main(String[] args) {
		Customer customer = new Customer();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name: ");
		customer.setFirstName(sc.nextLine());
		
		System.out.println("Enter Last Name: ");
		customer.setLastName(sc.nextLine());
		
		System.out.println("Enter email: ");
		customer.setEmail(sc.nextLine());
		
		System.out.println("Enter phone Number: ");
		customer.setPhoneNumber(sc.nextLine());
		
		CarRentalSystem dao = new CarRentalSystemImpl();
		try {
			System.out.println(dao.addCustomer(customer));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
