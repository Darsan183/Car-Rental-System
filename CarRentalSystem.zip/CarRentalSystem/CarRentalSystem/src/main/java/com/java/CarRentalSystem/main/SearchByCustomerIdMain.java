package com.java.CarRentalSystem.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Customer;

public class SearchByCustomerIdMain {

	 public static void main(String[] args) {
	        try {
	            CarRentalSystem dao = new CarRentalSystemImpl();
	            Scanner scanner = new Scanner(System.in);
	            System.out.print("Enter customerID: ");
	            int customerID = scanner.nextInt();

	            List<Customer> customers = dao.getCustomerById(customerID);
	            if (customers.isEmpty()) {
	                System.out.println("No record found.");
	            } else {
	                System.out.println("Details of the customer with customerID (" + customerID + "):");
	                for (Customer customer : customers) {
	                    System.out.println(customer);
	                }
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	        }
	    }
}
