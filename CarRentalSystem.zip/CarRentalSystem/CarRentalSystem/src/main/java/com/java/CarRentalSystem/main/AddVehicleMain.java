package com.java.CarRentalSystem.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Status;
import com.java.CarRentalSystem.model.Vehicle;

public class AddVehicleMain {

	public static void main(String[] args) {
		Vehicle vehicle = new Vehicle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Make: ");
		vehicle.setMake(sc.nextLine());
		
		System.out.println("Enter Model: ");
		vehicle.setModel(sc.nextLine());
		
		System.out.println("Enter year: ");
		vehicle.setYear(sc.nextInt());
		sc.nextLine();
		
		System.out.println("Enter Daily Rate: ");
		vehicle.setDailyRate(sc.nextDouble());
		sc.nextLine();
		
		System.out.println("Enter Status: ");
		vehicle.setStatus(Status.valueOf(sc.nextLine()));
		
		System.out.println("Enter Passenger Capacity: ");
		vehicle.setPassengerCapacity(sc.nextInt());
		
		System.out.println("Enter Engine Capacity: ");
		vehicle.setEngineCapacity(sc.nextInt());
		
		CarRentalSystem dao = new CarRentalSystemImpl();
		try {
			System.out.println(dao.addVehicle(vehicle));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
