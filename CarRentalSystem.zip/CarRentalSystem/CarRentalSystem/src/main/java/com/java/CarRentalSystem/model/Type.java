package com.java.CarRentalSystem.model;

public enum Type {

	DailyLease,MonthlyLease
}
