package com.java.CarRentalSystem.main;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import com.java.CarRentalSystem.dao.CarRentalSystem;
import com.java.CarRentalSystem.dao.CarRentalSystemImpl;
import com.java.CarRentalSystem.model.Lease;

import com.java.CarRentalSystem.model.Type;

public class AddLeaseMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter lease ID: ");
		int leaseID=sc.nextInt();
		
		System.out.println("Enter Vehicle ID: ");
		int vehicleID=sc.nextInt();
		
		System.out.println("Enter Customer ID: ");
		int customerID=sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter start Date: ");
		String startDate=sc.nextLine();
        
		System.out.println("Enter end Date: ");
		String endDate=sc.nextLine();
        
		System.out.println("Enter type: ");
		String type=sc.nextLine();
		
		CarRentalSystem dao = new CarRentalSystemImpl();
		Lease lease=new Lease(leaseID,vehicleID,customerID,Date.valueOf(startDate),Date.valueOf(endDate),Type.valueOf(type));

		try {
			System.out.println(dao.addLease(lease));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
